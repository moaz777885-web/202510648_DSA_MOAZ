/*
==========================================================================
    "Foundations and History of C++" — Interactive Book System
    A menu-driven program demonstrating menus, functions, and file I/O
==========================================================================
*/

#include <iostream>
#include <fstream>
#include <string>
#include <limits>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
//  UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

void clearScreen() {
    // Works on both Windows and Unix-like systems
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pauseScreen() {
    cout << "\n  Press ENTER to return to menu...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void printDivider(char c = '=', int width = 62) {
    cout << "\n  ";
    for (int i = 0; i < width; i++) cout << c;
    cout << "\n";
}

void printCentered(const string& text, int width = 62) {
    int padding = (width - (int)text.length()) / 2;
    if (padding < 0) padding = 0;
    cout << "  " << string(padding, ' ') << text << "\n";
}

// ─────────────────────────────────────────────────────────────────────────────
//  FILE STREAM READER — Loads a .txt chapter file and displays it
// ─────────────────────────────────────────────────────────────────────────────

void displayChapterFromFile(const string& filename) {
    ifstream inFile(filename);

    if (!inFile.is_open()) {
        cout << "\n  [ERROR] Could not open file: " << filename << "\n";
        cout << "  Make sure the 'chapters' folder is in the same\n";
        cout << "  directory as this executable.\n";
        return;
    }

    cout << "\n";
    string line;
    while (getline(inFile, line)) {
        cout << "  " << line << "\n";
    }

    inFile.close();
}

// ─────────────────────────────────────────────────────────────────────────────
//  HISTORY SECTION — Hardcoded chapters about C++ history
// ─────────────────────────────────────────────────────────────────────────────

void history_Chapter1() {
    clearScreen();
    printDivider('=');
    printCentered("CHAPTER 1: THE ORIGINS OF C++");
    printDivider('=');

    cout << "\n"
         << "  C++ was created by Danish computer scientist Bjarne\n"
         << "  Stroustrup. His journey began in 1979 at Bell Labs\n"
         << "  (Murray Hill, New Jersey), while working on his PhD\n"
         << "  dissertation at Cambridge University.\n"
         << "\n"
         << "  Stroustrup had been working with a language called\n"
         << "  Simula — the world's first object-oriented language —\n"
         << "  but found it too slow for serious systems programming.\n"
         << "  He loved its concepts but needed the raw performance\n"
         << "  of C.\n"
         << "\n"
         << "  This frustration led him to a simple but powerful idea:\n"
         << "  \"What if C had classes?\"\n"
         << "\n";

    printDivider('-');
    cout << "  1.1  \"C WITH CLASSES\" (1979–1983)\n";
    printDivider('-');

    cout << "\n"
         << "  Stroustrup's first implementation was literally called\n"
         << "  'C with Classes'. It added:\n"
         << "\n"
         << "    →  Classes and objects\n"
         << "    →  Basic inheritance\n"
         << "    →  Stronger type checking\n"
         << "    →  Inline functions\n"
         << "    →  Default function arguments\n"
         << "\n"
         << "  The implementation was a preprocessor called 'Cpre'\n"
         << "  that translated the new syntax into ordinary C code,\n"
         << "  which was then compiled by an existing C compiler.\n"
         << "\n";

    printDivider('-');
    cout << "  1.2  THE NAME \"C++\" (1983)\n";
    printDivider('-');

    cout << "\n"
         << "  In 1983, the language was renamed from 'C with Classes'\n"
         << "  to 'C++'. The name was coined by Rick Mascitti.\n"
         << "\n"
         << "  The '++' is a deliberate reference to C's increment\n"
         << "  operator (x++), meaning 'one step beyond C' — a\n"
         << "  language that extends and improves upon C.\n"
         << "\n"
         << "  The first C++ compiler — Cfront — was released in 1985,\n"
         << "  translating C++ code into C before compilation.\n"
         << "\n";

    printDivider('=');
    pauseScreen();
}

void history_Chapter2() {
    clearScreen();
    printDivider('=');
    printCentered("CHAPTER 2: STANDARDIZATION AND GROWTH");
    printDivider('=');

    cout << "\n"
         << "  Through the late 1980s and early 1990s, C++ grew\n"
         << "  enormously in popularity. Many compilers appeared\n"
         << "  from different vendors, but each implemented the\n"
         << "  language slightly differently — creating portability\n"
         << "  nightmares for developers.\n"
         << "\n";

    printDivider('-');
    cout << "  2.1  THE ANSI/ISO STANDARDIZATION EFFORT\n";
    printDivider('-');

    cout << "\n"
         << "  In 1989, ANSI (American National Standards Institute)\n"
         << "  formed a committee to standardize C++. ISO joined in\n"
         << "  1991. After years of debate and refinement:\n"
         << "\n"
         << "    1998 → C++98: The FIRST official ISO standard.\n"
         << "           Introduced the Standard Template Library (STL),\n"
         << "           templates, namespaces, and exception handling.\n"
         << "\n"
         << "    2003 → C++03: A bug-fix revision of C++98.\n"
         << "           No major new features; mostly clarifications.\n"
         << "\n";

    printDivider('-');
    cout << "  2.2  THE STANDARD TEMPLATE LIBRARY (STL)\n";
    printDivider('-');

    cout << "\n"
         << "  One of C++98's greatest contributions was the STL,\n"
         << "  developed primarily by Alexander Stepanov at HP.\n"
         << "\n"
         << "  The STL provided reusable, generic components:\n"
         << "\n"
         << "    Containers  →  vector, list, map, set, queue, ...\n"
         << "    Algorithms  →  sort(), find(), reverse(), ...\n"
         << "    Iterators   →  Uniform way to traverse containers\n"
         << "\n"
         << "  The STL transformed how C++ code was written, replacing\n"
         << "  manual array management with safe, efficient containers.\n"
         << "\n";

    printDivider('=');
    pauseScreen();
}

void history_Chapter3() {
    clearScreen();
    printDivider('=');
    printCentered("CHAPTER 3: THE MODERN C++ ERA");
    printDivider('=');

    cout << "\n"
         << "  After C++03, the language stagnated for nearly a decade.\n"
         << "  Developers jokingly referred to the next version as\n"
         << "  'C++0x' (the x meaning the release year was unknown).\n"
         << "  Finally, in 2011, the long-awaited update arrived.\n"
         << "\n";

    printDivider('-');
    cout << "  3.1  C++11 — THE BIG LEAP (2011)\n";
    printDivider('-');

    cout << "\n"
         << "  C++11 was the most significant update in the language's\n"
         << "  history. It modernized C++ dramatically:\n"
         << "\n"
         << "    auto keyword        →  Type deduction\n"
         << "    Lambda expressions  →  Anonymous functions\n"
         << "    Range-based for     →  for (auto x : container)\n"
         << "    nullptr             →  Replaces NULL\n"
         << "    Smart pointers      →  unique_ptr, shared_ptr\n"
         << "    Move semantics      →  Eliminates unnecessary copies\n"
         << "    std::thread         →  Built-in multithreading\n"
         << "    Uniform init        →  Braced initialization {}\n"
         << "\n";

    printDivider('-');
    cout << "  3.2  C++14, C++17, C++20, C++23\n";
    printDivider('-');

    cout << "\n"
         << "  C++14 (2014):\n"
         << "    Minor improvements; generic lambdas, return type\n"
         << "    deduction, std::make_unique.\n"
         << "\n"
         << "  C++17 (2017):\n"
         << "    Structured bindings, std::optional, std::variant,\n"
         << "    std::filesystem, if constexpr, parallel algorithms.\n"
         << "\n"
         << "  C++20 (2020):\n"
         << "    Concepts, Coroutines, Modules, Ranges library,\n"
         << "    std::format, Calendar and Timezone library.\n"
         << "\n"
         << "  C++23 (2023):\n"
         << "    std::print, std::expected, more ranges/ranges\n"
         << "    improvements, deducing this, and many library fixes.\n"
         << "\n";

    printDivider('-');
    cout << "  3.3  C++ TODAY\n";
    printDivider('-');

    cout << "\n"
         << "  C++ remains one of the most widely used programming\n"
         << "  languages in the world. It powers:\n"
         << "\n"
         << "    → Operating systems (Windows, parts of Linux/macOS)\n"
         << "    → Game engines (Unreal Engine, id Tech)\n"
         << "    → Browsers (Chrome, Firefox)\n"
         << "    → Databases (MySQL, MongoDB)\n"
         << "    → Financial systems (high-frequency trading)\n"
         << "    → Embedded systems and robotics\n"
         << "    → Machine learning frameworks (TensorFlow core)\n"
         << "\n"
         << "  Bjarne Stroustrup, now in his 70s, continues to actively\n"
         << "  participate in the C++ standards committee.\n"
         << "\n";

    printDivider('=');
    pauseScreen();
}

void history_Chapter4() {
    clearScreen();
    printDivider('=');
    printCentered("CHAPTER 4: C++ VS OTHER LANGUAGES");
    printDivider('=');

    cout << "\n"
         << "  Understanding C++'s place among other languages helps\n"
         << "  appreciate why it remains relevant after 40+ years.\n"
         << "\n";

    printDivider('-');
    cout << "  4.1  C++ VS C\n";
    printDivider('-');

    cout << "\n"
         << "  C++ is nearly a superset of C. Almost all valid C code\n"
         << "  is valid C++ code. The major additions are:\n"
         << "\n"
         << "    C++ Adds:  Classes, Inheritance, Polymorphism,\n"
         << "               Templates, Exceptions, References,\n"
         << "               Operator overloading, Namespaces,\n"
         << "               Stronger type checking, STL.\n"
         << "\n"
         << "  C is still preferred for: OS kernels, device drivers,\n"
         << "  and environments where C++ runtime is unavailable.\n"
         << "\n";

    printDivider('-');
    cout << "  4.2  C++ VS JAVA\n";
    printDivider('-');

    cout << "\n"
         << "  Java (1995) was partly inspired by C++ but made\n"
         << "  different trade-offs:\n"
         << "\n"
         << "    C++   → Manual memory, pointers, direct hardware access,\n"
         << "            maximum performance, platform-dependent.\n"
         << "\n"
         << "    Java  → Garbage collection, no pointers, JVM portability,\n"
         << "            safer but with overhead.\n"
         << "\n";

    printDivider('-');
    cout << "  4.3  C++ VS PYTHON\n";
    printDivider('-');

    cout << "\n"
         << "    C++    → Compiled, statically typed, very fast,\n"
         << "             verbose, steep learning curve.\n"
         << "\n"
         << "    Python → Interpreted, dynamically typed, slower,\n"
         << "             concise, beginner-friendly.\n"
         << "\n"
         << "  Interestingly, Python itself is implemented IN C,\n"
         << "  and many Python performance libraries (NumPy, TensorFlow)\n"
         << "  are written in C++.\n"
         << "\n";

    printDivider('=');
    pauseScreen();
}

// ─────────────────────────────────────────────────────────────────────────────
//  HISTORY MENU
// ─────────────────────────────────────────────────────────────────────────────

void historyMenu() {
    int choice;
    bool back = false;

    while (!back) {
        clearScreen();
        printDivider('=');
        printCentered("PART I — HISTORY OF C++");
        printDivider('=');
        cout << "\n"
             << "  Select a chapter:\n"
             << "\n"
             << "  [1]  Chapter 1 — The Origins of C++\n"
             << "  [2]  Chapter 2 — Standardization and Growth\n"
             << "  [3]  Chapter 3 — The Modern C++ Era\n"
             << "  [4]  Chapter 4 — C++ vs Other Languages\n"
             << "\n"
             << "  [0]  Back to Main Menu\n";
        printDivider('-');
        cout << "  Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: history_Chapter1(); break;
            case 2: history_Chapter2(); break;
            case 3: history_Chapter3(); break;
            case 4: history_Chapter4(); break;
            case 0: back = true;        break;
            default:
                cout << "\n  Invalid choice. Please try again.\n";
                pauseScreen();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  LEARN MENU — reads chapters from .txt files using ifstream
// ─────────────────────────────────────────────────────────────────────────────

void learnMenu() {
    int choice;
    bool back = false;

    // Chapter file paths (relative to executable location)
    const string chapterFiles[] = {
        "chapters/datatypes.txt",
        "chapters/controlflow.txt",
        "chapters/loops.txt",
        "chapters/arrays.txt",
        "chapters/filestreams.txt"
    };

    while (!back) {
        clearScreen();
        printDivider('=');
        printCentered("PART II — LEARN C++ CONCEPTS");
        printDivider('=');
        cout << "\n"
             << "  Select a chapter:\n"
             << "\n"
             << "  [1]  Chapter 1 — Data Types\n"
             << "  [2]  Chapter 2 — Control Flow\n"
             << "  [3]  Chapter 3 — Loops\n"
             << "  [4]  Chapter 4 — Arrays\n"
             << "  [5]  Chapter 5 — File Streams\n"
             << "\n"
             << "  [0]  Back to Main Menu\n";
        printDivider('-');
        cout << "  Enter choice: ";
        cin >> choice;

        if (choice >= 1 && choice <= 5) {
            clearScreen();
            // Use ifstream to read and display the chapter from file
            displayChapterFromFile(chapterFiles[choice - 1]);
            pauseScreen();
        } else if (choice == 0) {
            back = true;
        } else {
            cout << "\n  Invalid choice. Please try again.\n";
            pauseScreen();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SPLASH / TITLE SCREEN
// ─────────────────────────────────────────────────────────────────────────────

void showSplash() {
    clearScreen();
    printDivider('=');
    cout << "\n";
    printCentered("FOUNDATIONS AND HISTORY OF C++");
    printCentered("An Interactive Learning Book");
    cout << "\n";
    printDivider('=');
    cout << "\n"
         << "  Welcome! This interactive book covers:\n"
         << "\n"
         << "    PART I  →  The History and Evolution of C++\n"
         << "    PART II →  Core C++ Programming Concepts\n"
         << "\n"
         << "  Navigate using the numbered menus.\n"
         << "  Enter 0 at any menu to go back.\n"
         << "\n";
    printDivider('-');
    cout << "  Press ENTER to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN MENU
// ─────────────────────────────────────────────────────────────────────────────

void mainMenu() {
    int choice;
    bool running = true;

    while (running) {
        clearScreen();
        printDivider('=');
        printCentered("FOUNDATIONS AND HISTORY OF C++");
        printDivider('=');
        cout << "\n"
             << "  MAIN MENU\n"
             << "\n"
             << "  [1]  History of C++\n"
             << "  [2]  Learn C++ Concepts\n"
             << "  [0]  Exit\n";
        printDivider('-');
        cout << "  Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                historyMenu();
                break;
            case 2:
                learnMenu();
                break;
            case 0:
                clearScreen();
                printDivider('=');
                printCentered("Thank you for reading!");
                printCentered("\"C++ is a tool for writing efficient,");
                printCentered(" reliable, and scalable programs.\"");
                printCentered("— Bjarne Stroustrup");
                printDivider('=');
                cout << "\n";
                running = false;
                break;
            default:
                cout << "\n  Invalid option. Please enter 0, 1, or 2.\n";
                pauseScreen();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────

int main() {
    showSplash();
    mainMenu();
    return 0;
}
